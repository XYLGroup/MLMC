import os
import argparse
import torch
import sys
import cv2
import numpy as np
import warnings
import random
warnings.filterwarnings("ignore")
import matplotlib.pyplot as plt
from util import read_image, im2tensor01, map2tensor, tensor2im01, analytic_kernel, kernel_shift, evaluation_dataset, modcrop
from config.configs import Config
from model.model import MLMC
from PIL import Image
import time
import datetime

sys.path.append('../')


'''
# ------------------------------------------------
# main.py for MLMC
# ------------------------------------------------
'''


def train(conf, lr_image, hr_image):
    ''' trainer for MLMC, etc.'''
    model = MLMC(conf, lr_image, hr_image)

    kernel, sr = model.train()
    return kernel, sr


def create_params(filename, args):
    ''' pass parameters to Config '''
    params = ['--model', args.model,
              '--input_image_path', args.input_dir + '/' + filename,
              '--output_dir_path', os.path.abspath(args.output_dir),
              '--sf', args.sf]
    if args.SR:
        params.append('--SR')
    if args.real:
        params.append('--real')
    return params


def main():

    prog = argparse.ArgumentParser()

    prog.add_argument('--model', type=str, default="MLMC", help='models: MLMC.')
    prog.add_argument('--dataset', '-d', type=str, default='Set5',
                      help='dataset, e.g., Set5, Set14, BSD100, Urban100.')
    prog.add_argument('--max_iterations', type=str, default="120", help='100')
    prog.add_argument('--sf', type=str, default='4', help='The wanted SR scale factor')
    prog.add_argument('--SR', action='store_true', default=False, help='when activated - nonblind SR is performed')
    prog.add_argument('--real', action='store_true', default=False, help='if the input is real image')

    # to be overwritten automatically
    prog.add_argument('--input-dir', '-i', type=str, default='../data/datasets/Set5/MLMC_lr_x2',
                      help='path to image input directory.')
    prog.add_argument('--output-dir', '-o', type=str,
                      default='../data/log_MLMC/Set5_MLMC_lr_x2', help='path to image output directory')

    args = prog.parse_args()


    # Parse the command line arguments
    now_time = str(datetime.datetime.now())[:-10].replace(':', '-')
    D_loop = 15  # L
    kernel_first_iteration = 280
    I_loop_x = 4  # P
    I_loop_k = 1  # Q
    SSIM_iterations = 80 // I_loop_x  # 80
    noise_estimator = "iid"  # "iid" or "niid" or "no-noise"
    var_min_add = 3
    var_max_add = 10
    grad_loss_lr = 1
    Intermediate_visual = True
    IF_print = False
    model_num = "_x{}_{}".format(args.sf, now_time)

    # overwritting paths

    args.input_dir = '../data/datasets/{}/MLMC_lr_x{}'.format(args.dataset, args.sf)
    args.hr_dir = '../data/datasets/{}/HR'.format(args.dataset)
    args.output_dir = '../data/log_{}/{}_{}_lr_x{}'.format(args.model, args.dataset, args.model, model_num)

    if not os.path.isdir(args.output_dir + "_" + args.model):
        os.makedirs(args.output_dir + "_" + args.model)

    filesource = os.listdir(os.path.abspath(args.input_dir))
    filesource.sort()
    for filename in filesource[:]:
        print(filename)
        conf = Config().parse(create_params(filename, args))
        conf.max_iters = int(args.max_iterations)
        conf.verbose = Intermediate_visual
        conf.SSIM_iterations = SSIM_iterations
        conf.kernel_first_iteration = kernel_first_iteration
        conf.D_loop = D_loop
        conf.I_loop_x = I_loop_x
        conf.I_loop_k = I_loop_k
        conf.kernel_x = (int(args.sf) + 1) * 3 / 2
        conf.kernel_y = conf.kernel_x
        conf.var_min_add = var_min_add
        conf.var_max_add = var_max_add
        conf.model_num = model_num
        conf.grad_loss_lr = grad_loss_lr
        conf.noise_estimator = noise_estimator
        conf.IF_print = IF_print
        conf.input_dir = args.input_dir
        conf.filename = filename
        conf.model_num = model_num
        conf.method = args.model


        lr_image = im2tensor01(read_image(os.path.join(args.input_dir, filename))).unsqueeze(0)

        if args.real == False:
            hr_img = read_image(os.path.join(args.hr_dir, filename))
            hr_image = im2tensor01(hr_img).unsqueeze(0)
        else:
            hr_image = torch.ones(lr_image.shape[0], lr_image.shape[1], lr_image.shape[2]*int(args.sf), lr_image.shape[3]*int(args.sf))

        # crop the image to 960x960 due to memory limit

        if 'DIV2K' in args.input_dir:
            crop_size = 800
            size_min = min(hr_image.shape[2], hr_image.shape[3])
            if size_min > crop_size:
                crop = int(crop_size / 2 / conf.sf)
                lr_image = lr_image[:, :, lr_image.shape[2] // 2 - crop: lr_image.shape[2] // 2 + crop,
                           lr_image.shape[3] // 2 - crop: lr_image.shape[3] // 2 + crop]
                hr_image = hr_image[:, :, hr_image.shape[2] // 2 - crop * 2: hr_image.shape[2] // 2 + crop * 2,
                           hr_image.shape[3] // 2 - crop * 2: hr_image.shape[3] // 2 + crop * 2]

            conf.IF_DIV2K = True
            conf.crop = crop

        strat_time = time.time()
        kernel, sr_dip = train(conf, lr_image, hr_image)
        Runtime = time.time() - strat_time
        print("method:", args.model, "Runtime:", "%.2f" % Runtime)

        plt.imsave(os.path.join(conf.output_dir_path, '%s.png' % conf.img_name), tensor2im01(sr_dip), vmin=0,
                   vmax=1., dpi=1)

    if args.real == False:
        evaluation_dataset(args.input_dir, conf.output_dir_path, conf)

if __name__ == '__main__':
    seed = 0
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.backends.cudnn.benchmark = True

    main()
